//�û���Ϣ
public class User {
	public String name;
	public String sex;
	public int picture;
}
